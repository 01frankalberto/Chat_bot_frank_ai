from flask import Flask, render_template, request, jsonify
import openai
import os

app = Flask(__name__)

# Lee la API Key desde variables de entorno (más seguro en Render/Railway)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")

    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",   # o "gpt-3.5-turbo"
        messages=[{"role": "user", "content": user_message}]
    )

    reply = response.choices[0].message.content
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
